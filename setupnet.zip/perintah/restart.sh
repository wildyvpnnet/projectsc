#!/bin/bash
#Restart Semua Services Pada VPS

service dropbear restart
sleep 2
echo "[OKEY] Beruang Jatuh Berhasil Di Restart......."
service webmin restart
sleep 1
echo "[OKEY] Webmin Berhasil Di Restart.............."
service squid3 restart
sleep 2
echo "[OKEY] Squid3 Berhasil DI Restart.............."
service openvpn restart
sleep 2
echo "[OKEY] BukaVPN Berhasil Di Restart............."
service ssh restart
sleep 1
echo "[OKEY] SSH Server Berhasil DI Restart.........."
