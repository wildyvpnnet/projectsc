#!/bin/bash
#Script Install SSH By WILDYVPN

clear
neofetch
echo "Script Created By WildyVPN"
echo -e ""
echo -e "========================================"
echo -e "*   SCRIPT AUTO INSTALL BY WILDY VPN   *"
echo -e "========================================"
echo -e ""
read -p "Username SSH = " nama
read -p "Password SSH = " sandi
read -p "Masa Aktif SSH = " masaaktif
echo -e ""
echo -e "Okey Bos Data Di Terima dan akan di buat"
echo -e "  Dalam Waktu 2 Detik Is Jadi Sayang ah "
echo -e ""
echo -e "========================================"
echo -e "*   SCRIPT AUTO INSTALL BY WILDY VPN   *"
echo -e "========================================"
sleep 2
clear
wildyvpn=`curl icanhazip.com`
useradd -e `date -d "$masaaktif days" +"%Y-%m-%d"` -s /bin/false -M $nama
exp="$(chage -l $nama | grep "Account expires" | awk -F": " '{print $2}')"
echo -e "$sandi\n$sandi\n"|passwd $nama &> /dev/null
echo ""
clear
echo -e "
=========================
    Informasi Akun SSH Prem
=========================
Identitas = $wildyvpn
Nama = $nama
Sandi = $sandi
BukaSSH = 22
Lubang SSL = 443,123  
BeruangJatuh = 443,143
Lubang Squid = 80,3128
VpnJelek = 7100-7300
OVpn Tcp = http://$wildyvpn:81/client.ovpn         
=========================
Umur Akun = $exp 
=========================
Script Auto By WILDYVPN"



