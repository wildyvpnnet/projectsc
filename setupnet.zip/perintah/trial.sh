#!/bin/bash

clear
neofetch
echo "Script Created By WildyVPN"
echo ""
echo -e "========================================"
echo -e "*   SCRIPT AUTO INSTALL BY WILDY VPN   *"
echo -e "========================================"
echo -e ""
read -p " Mau Kasih Trial Brp Jam = " jam
echo -e ""
echo -e "Okey Bos Data Di Terima dan akan di buat"
echo -e " Dalam Waktu 3 Detik Is Jadi Sayang ah  "
echo -e ""
echo -e "========================================"
echo -e "*   SCRIPT AUTO INSTALL BY WILDY VPN   *"
echo -e "========================================"
sleep 3
IP=`curl icanhazip.com`
Login=trial`</dev/urandom tr -dc X-Z0-9 | head -c3`
Pass=123
useradd -e `date -d "$jam hours" +"%Y-%m-%d"` -s /bin/false -M $Login
echo -e "$Pass\n$Pass\n"|passwd $Login &> /dev/null
clear
echo -e ""
echo -e "
=========================
    Informasi Akun SSH Trial
=========================
Identitas = $IP
Nama = $Login
Sandi = $Pass
BukaSSH = 22
Lubang SSL = 443,123  
BeruangJatuh = 443,143
Lubang Squid = 80,3128
VpnJelek = 7100-7300
OVpn Tcp = http://$IP:81/client.ovpn         
=========================
Umur SSH Trial Anda = $jam Jam
=========================
Script Auto By WILDYVPN"

