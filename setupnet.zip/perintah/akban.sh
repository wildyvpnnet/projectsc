#!/bin/bash
# 
#Script Created BY WILDYVPN

echo "Banner /etc/wildyvpn" >> /etc/ssh/sshd_config
clear
neofetch
echo ""
echo -e "[PROSES] Silakan Tunggu Sebentar................"
rm /etc/wildyvpn
echo "<H3>Selamat Datang Di $HOSTNAME</H3>" >> /etc/wildyvpn
echo "<H4>Peraturan Di $HOSTNAME</h4>" >> /etc/wildyvpn
echo "<H4>1. Jangan Melakukan Torrent</h4>" >> /etc/wildyvpn
echo "<H4>2. Jangan Melakukan DDOS</h4>" >> /etc/wildyvpn
echo "<H4>3. Jangan Melakukan Hacking</h4>" >> /etc/wildyvpn
echo "<H4>4. Jangan Jav</h4>" >> /etc/wildyvpn
echo "<br>" >> /etc/wildyvpn
echo "<H5>&copy Copyright 2021 By WildyVPN</h5>" >>/etc/wildyvpn
sleep 1
echo -e ""
echo -e "[OKEY] Berhasil Mengaktifkan Banner SSH........."
sleep 1
echo -e ""
echo -e ""
echo -e "========================================"
echo -e "*   SCRIPT AUTO INSTALL BY WILDY VPN   *"
echo -e "========================================"
echo -e ""
echo -e "Lokasi / Tempat Banner Berada adalah Di-"
echo -e "/etc/wildyvpn -> Jika Ingin Mengedit "
echo -e "Silakan Ketik nano /etc/wildyvpn Utk Edit"
echo -e ""
echo -e "========================================"
echo -e "*   SCRIPT AUTO INSTALL BY WILDY VPN   *"
echo -e "========================================"