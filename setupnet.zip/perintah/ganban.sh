#!/bin/bash
# 
#Script Created BY WILDYVPN

clear
neofetch
echo -e "Script Created By WildyVPN"
echo ""
rm /etc/wildyvpn
echo ""
echo -e "========================================"
echo -e "*   SCRIPT AUTO INSTALL BY WILDY VPN   *"
echo -e "========================================"
echo -e ""
echo -e "   Banner SSH Telah Berhasil DI Hapus "
echo -e ""
echo -e "========================================"
echo -e "*   SCRIPT AUTO INSTALL BY WILDY VPN   *"
echo -e "========================================"