#!/bin/bash
#Created By WILDYVPN
cd
clear
neofetch
echo -e "================= Daftar Menu ================="
echo -e "* menu       = Melihat Daftar Menu Script     *"
echo -e "* new        = Membuat Akun SSH / OVPN        *"
echo -e "* trial      = Membuat Akun Trial SSH / OVPN  *"
echo -e "* cek        = Melihat User Login DI SSH      *"
echo -e "* total      = Melihat Total User SSH Di VPS  *"
echo -e "* hapus      = Menghapus Akun SSH Yang Bandel *"
echo -e "* speed      = Speedtest Speed Pada Server    *"
echo -e "* restart    = Merestart Semua Layanan Script *"
echo -e "================ Menu Tambahan ================"
echo -e "* akban      = Mengaktifkan Banner Pada SSH   *"
echo -e "* delban     = Menghapus Banner               *"
echo -e "* reban      = Mengembalikan Banner KeDefault *"
echo -e "================= Menu System ================="
echo -e "* vnstat     = Melihat Total Pemakaian BW     *"
echo -e "* reboot     = Mereboot Server / VPS          *"
echo -e "* exit       = Keluar Dari VPS Remote         *"
echo -r "* tentang    = Melihat Informasi Script       *"
echo -e "==============================================="
echo -e ""
echo -e "Script Created By WIldyVPN"
