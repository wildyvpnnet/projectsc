#!/bin/bash
# Script Created By WildyVPN

clear
neofetch
echo ""
echo -e "========================================"
echo -e "*   SCRIPT AUTO INSTALL BY WILDY VPN   *"
echo -e "========================================"
read -p " Masukin Username = " wildyvpnpastibisa
echo -e "========================================"
echo -e "*   SCRIPT AUTO INSTALL BY WILDY VPN   *"
echo -e "========================================"
echo ""
clear
neofetch
echo "Script Created By WildyVPN"
echo ""
userdel -r $wildyvpnpastibisa
echo -e "======================================="
echo -e "= USER BANDEL TELAH BERHASIL DI HAPUS ="
echo -e "======================================="