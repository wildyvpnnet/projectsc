#!/bin/bash
# 
#Script Created BY WILDYVPN

clear
neofetch
echo ""
echo -e "[PROSES] Silakan Tunggu Sebentar............/............."
rm /etc/wildyvpn
echo "<H3>Selamat Datang Di $HOSTNAME</H3>" >> /etc/wildyvpn
echo "<H4>Peraturan Di $HOSTNAME</h4>" >> /etc/wildyvpn
echo "<H4>1. Jangan Melakukan Torrent</h4>" >> /etc/wildyvpn
echo "<H4>2. Jangan Melakukan DDOS</h4>" >> /etc/wildyvpn
echo "<H4>3. Jangan Melakukan Hacking</h4>" >> /etc/wildyvpn
echo "<H4>4. Jangan Jav</h4>" >> /etc/wildyvpn
echo "<br>" >> /etc/wildyvpn
echo "<H5>&copy Copyright 2021 By WildyVPN</h5>" >>/etc/wildyvpn
sleep 1
echo -e ""
echo -e "[OKEY] Banner SSH Telah Di Kembalikan Ke Default........."